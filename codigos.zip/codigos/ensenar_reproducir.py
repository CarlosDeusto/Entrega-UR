"""Bloque D (sobresaliente): enseñar y reproducir una secuencia de puntos.

Uso: python ensenar_reproducir.py [IP]
Sin IP se usa la del primer robot de robots.json.

El estado se lee por la interfaz primaria (30001) y las órdenes URScript se
escriben en ese mismo socket. El robot sólido sigue al real; el translúcido
muestra la postura de los deslizadores o la previsualización de la secuencia.

Al pasar el robot real a modo Remoto, la conexión abierta antes no acepta
programas. Por eso, al pulsar E se cierra la conexión, se abre otra y se
espera a su primer estado antes de enviar el primer movej.

Teclas, con la ventana de PyBullet activa:
  A  añadir la postura actual del robot
  D  añadir la postura de los deslizadores (robot translúcido)
  T  copiar la postura actual del robot a los deslizadores
  B  borrar el último punto
  V  previsualizar la secuencia en el robot translúcido
  E  ejecutar la secuencia en el robot (antes rehace la conexión)
  R  reanudar una secuencia detenida
  C  cancelar la secuencia (detiene el robot si se está moviendo)
  G  guardar la secuencia en secuencia.json
  L  cargar la secuencia de secuencia.json
  H  mostrar esta ayuda
"""
import json
import math
import socket
import sys
import threading
import time
from pathlib import Path

import pybullet as p
from UR3e_rg2.dynamic_ur3e import UR3eRG2

import primaria
import tiempo_real
from configuracion import ip_destino
from primaria import MODOS, en_grados, ventana_abierta

VELOCIDAD = 0.3           # rad/s, límite obligatorio en el robot real
ACELERACION = 0.5         # rad/s², límite obligatorio en el robot real
TOLERANCIA = 0.01         # rad por articulación para dar un punto por alcanzado
TIEMPO_INICIO = 2         # s para que isProgramRunning pase a verdadero
MARGEN_MOVIMIENTO = 5     # s añadidos al tiempo estimado de cada movimiento
TIEMPO_RECONEXION = 5     # s para abrir la conexión nueva y recibir su primer estado
LIMITE_ANGULO = 2 * math.pi
VELOCIDAD_PREVIA = 0.6    # rad/s de la animación de previsualización
PAUSA_PREVIA = 0.5        # s quieto en cada punto de la previsualización
FICHERO = Path(__file__).with_name("secuencia.json")
COLOR_FANTASMA = [0.2, 0.6, 1.0, 0.35]
CAMPOS_ROBOT = ("conectado", "q", "modo") + tiempo_real.INDICADORES
AYUDA = __doc__[__doc__.index("Teclas"):].rstrip()


def validar_punto(q):
    """Devuelve q como lista de seis floats o lanza ValueError.

    movej interpreta radianes: un ángulo en grados daría varias vueltas.
    """
    if not isinstance(q, (list, tuple)) or len(q) != 6:
        raise ValueError("un punto debe tener seis ángulos")
    punto = []
    for angulo in q:
        if isinstance(angulo, bool) or not isinstance(angulo, (int, float)):
            raise ValueError("los ángulos deben ser números")
        try:
            angulo = float(angulo)
        except OverflowError:
            angulo = math.inf
        if not math.isfinite(angulo) or abs(angulo) > LIMITE_ANGULO:
            raise ValueError(f"el ángulo {angulo:.3f} rad está fuera de ±2π (¿está en grados?)")
        punto.append(angulo)
    return punto


def orden_movej(q):
    angulos = ", ".join(f"{angulo:.6f}" for angulo in validar_punto(q))
    return f"movej([{angulos}], a={ACELERACION}, v={VELOCIDAD})"


def distancia(q1, q2):
    """Mayor diferencia entre articulaciones, en radianes."""
    return max(abs(a - b) for a, b in zip(q1, q2))


def guardar_secuencia(puntos, ruta=FICHERO):
    # Se escribe en un temporal y se renombra para no dejar un fichero a medias.
    temporal = ruta.with_suffix(".tmp")
    temporal.write_text(json.dumps({"puntos": puntos}, indent=2), encoding="utf-8")
    temporal.replace(ruta)


def cargar_secuencia(ruta=FICHERO):
    try:
        datos = json.loads(ruta.read_text(encoding="utf-8-sig"))
    except OSError as error:
        raise ValueError(f"no se puede leer {ruta.name}: {error}") from error
    except ValueError as error:
        raise ValueError(f"{ruta.name} no contiene un JSON válido: {error}") from error
    if not isinstance(datos, dict) or not isinstance(datos.get("puntos"), list):
        raise ValueError(f"{ruta.name} debe contener un objeto con la lista 'puntos'")
    puntos = []
    for numero, q in enumerate(datos["puntos"], start=1):
        try:
            puntos.append(validar_punto(q))
        except ValueError as error:
            raise ValueError(f"punto {numero} de {ruta.name}: {error}") from error
    return puntos


def motivo_para_no_mover(robot):
    """Condiciones previas para enviar una orden, o None si se cumplen."""
    if not robot["conectado"]:
        return "no hay conexión con el robot"
    if robot["q"] is None or robot["programa_en_marcha"] is None:
        return "todavía no se ha recibido el estado del robot"
    if robot["parada_emergencia"]:
        return "el robot está en parada de emergencia"
    if robot["parada_proteccion"]:
        return "el robot está en parada de protección; desbloquéalo en PolyScope"
    if robot["modo"] != 7:
        modo = MODOS.get(robot["modo"], f"modo {robot['modo']}")
        return f"el robot debe estar encendido y con los frenos liberados (ahora: {modo})"
    if robot["programa_en_marcha"]:
        return "ya hay un programa en marcha en el robot"
    return None


class Secuenciador:
    """Envía un movej por punto y no pasa al siguiente hasta confirmar el anterior.

    El robot no contesta a las órdenes: el ACK de TCP solo indica que los bytes
    han llegado. El resultado se deduce del estado que sigue publicando:
    isProgramRunning, q_actual, las paradas y los mensajes de error.
    """

    def __init__(self, enviar):
        self.enviar = enviar        # función que escribe una línea URScript
        self.fase = "parada"        # parada, esperando_inicio, en_movimiento o pausada
        self.puntos = []
        self.indice = 0
        self.limite = 0
        self.duracion = 0
        self.motivo = ""
        self.avisos = []            # mensajes del robot desde la última orden

    @property
    def activa(self):
        return self.fase in ("esperando_inicio", "en_movimiento")

    def descripcion(self):
        if self.fase == "parada":
            return "parada"
        punto = f"punto {self.indice + 1}/{len(self.puntos)}"
        if self.fase == "pausada":
            return f"detenida en el {punto}: {self.motivo}"
        return f"ejecutando el {punto}"

    def iniciar(self, puntos, robot, ahora):
        if self.fase != "parada":
            print("Ya hay una secuencia en curso: reanúdala con R o cancélala con C.")
            return
        if not puntos:
            print("No hay puntos que ejecutar.")
            return
        motivo = motivo_para_no_mover(robot)
        if motivo:
            print(f"No se puede ejecutar: {motivo}.")
            return
        # Copia: editar la lista durante la ejecución no cambia lo que se ejecuta.
        self.puntos = [list(q) for q in puntos]
        self.indice = 0
        print(f"Ejecutando una secuencia de {len(self.puntos)} puntos.")
        self._siguiente(robot, ahora)

    def reanudar(self, robot, ahora):
        if self.fase != "pausada":
            print("No hay ninguna secuencia detenida.")
            return
        motivo = motivo_para_no_mover(robot)
        if motivo:
            print(f"No se puede reanudar: {motivo}.")
            return
        print(f"Reanudando desde el punto {self.indice + 1}.")
        self._siguiente(robot, ahora)

    def cancelar(self, robot):
        if self.fase == "parada":
            return
        if self.activa and robot["conectado"]:
            self._detener_robot()
        self.fase = "parada"
        print("Secuencia cancelada.")

    def actualizar(self, robot, mensajes, ahora):
        """Avanza la secuencia con el último estado y los mensajes nuevos."""
        self.avisos += mensajes
        if not self.activa:
            return
        graves = [mensaje for mensaje in mensajes if mensaje["grave"]]
        if not robot["conectado"]:
            self._pausar("se ha perdido la conexión con el robot", robot)
        elif robot["parada_emergencia"]:
            self._pausar("parada de emergencia", robot)
        elif robot["parada_proteccion"]:
            self._pausar("parada de protección", robot)
        elif graves:
            self._pausar(f"el robot ha informado de un error: {graves[-1]['texto']}", robot)
        elif self.fase == "esperando_inicio":
            if robot["programa_en_marcha"]:
                self.fase = "en_movimiento"
                self.limite = ahora + self.duracion
            elif ahora > self.limite:
                if distancia(robot["q"], self.puntos[self.indice]) <= TOLERANCIA:
                    # Un movimiento muy corto puede acabar entre dos estados de 10 Hz.
                    self.indice += 1
                    self._siguiente(robot, ahora)
                    return
                ultimo = f" Último mensaje del robot: {self.avisos[-1]['texto']}" if self.avisos else ""
                self._pausar(f"el robot no ha empezado la orden en {TIEMPO_INICIO} s; comprueba "
                             f"que esté en modo Remoto.{ultimo}", robot)
        elif not robot["programa_en_marcha"]:
            error = distancia(robot["q"], self.puntos[self.indice])
            if error <= TOLERANCIA:
                print(f"Punto {self.indice + 1}/{len(self.puntos)} alcanzado "
                      f"(error máximo {error:.4f} rad).")
                self.indice += 1
                self._siguiente(robot, ahora)
            else:
                self._pausar(f"el programa ha terminado lejos del punto (error máximo {error:.3f} rad)",
                             robot)
        elif ahora > self.limite:
            self._pausar("el movimiento tarda más de lo previsto", robot)

    def _siguiente(self, robot, ahora):
        # Un punto en el que ya está el robot no se envía: el programa duraría
        # tan poco que no se vería isProgramRunning y parecería rechazado.
        while (self.indice < len(self.puntos)
               and distancia(robot["q"], self.puntos[self.indice]) <= TOLERANCIA):
            print(f"Punto {self.indice + 1}/{len(self.puntos)}: el robot ya está en él.")
            self.indice += 1
        if self.indice == len(self.puntos):
            self.fase = "parada"
            print("Secuencia completada.")
            return
        objetivo = self.puntos[self.indice]
        self.avisos = []
        try:
            self.enviar(orden_movej(objetivo))
        except (OSError, ValueError) as error:
            self._pausar(f"no se ha podido enviar la orden: {error}", robot)
            return
        self.fase = "esperando_inicio"
        self.limite = ahora + TIEMPO_INICIO
        # movej acelera y frena: se da el doble del tiempo a velocidad constante.
        self.duracion = 2 * distancia(robot["q"], objetivo) / VELOCIDAD + MARGEN_MOVIMIENTO

    def _pausar(self, motivo, robot):
        # Solo se manda stopj si el programa sigue en marcha. En una parada el
        # robot ya está quieto y no aceptaría la orden.
        if (robot["conectado"] and robot["programa_en_marcha"]
                and not robot["parada_proteccion"] and not robot["parada_emergencia"]):
            self._detener_robot()
        self.fase = "pausada"
        self.motivo = motivo
        print(f"SECUENCIA DETENIDA en el punto {self.indice + 1}/{len(self.puntos)}: {motivo}")
        print("Pulsa R para reanudar o C para cancelar.")

    def _detener_robot(self):
        try:
            self.enviar(f"stopj({ACELERACION})")
        except OSError as error:
            print(f"No se ha podido enviar stopj: {error}")


class Previsualizacion:
    """Recorre los puntos en el robot translúcido a velocidad constante."""

    def __init__(self, inicio, puntos, ahora):
        self.tramos = []
        anterior = inicio
        for punto in puntos:
            self.tramos.append((anterior, punto, max(0.2, distancia(anterior, punto) / VELOCIDAD_PREVIA)))
            anterior = punto
        self.comienzo = ahora

    def pose(self, ahora):
        """Postura en el instante ahora, o None si ya ha terminado."""
        t = ahora - self.comienzo
        for desde, hasta, duracion in self.tramos:
            if t < duracion:
                return [a + (b - a) * t / duracion for a, b in zip(desde, hasta)]
            t -= duracion
            if t < PAUSA_PREVIA:
                return list(hasta)
            t -= PAUSA_PREVIA
        return None


def enviar_urscript(estado, texto):
    """Escribe una orden en el socket de la primaria del que lee el receptor.

    Sin el salto de línea final el controlador no ejecuta nada; sendall
    garantiza que se escriben todos los bytes.
    """
    with estado["lock"]:
        conexion = estado["conexion"]
    if conexion is None:
        raise ConnectionError("no hay conexión con el robot")
    conexion.sendall((texto + "\n").encode("utf-8"))
    print(f"Enviado: {texto}")


def rehacer_conexion(estado):
    """Cierra la conexión actual para que el receptor abra otra enseguida.

    Devuelve False si no había conexión. Se marca como desconectado desde ya
    para que el bucle principal no use estados de la conexión antigua.
    """
    with estado["lock"]:
        conexion = estado["conexion"]
        if conexion is None:
            return False
        estado.update(dict.fromkeys(tiempo_real.INDICADORES), conectado=False, reconectar=True)
    try:
        # shutdown hace que el recv() del receptor termine y cierre el socket.
        conexion.shutdown(socket.SHUT_RDWR)
    except OSError:
        pass
    return True


def crear_fantasma(visualizador):
    fantasma = visualizador.spawn_robot([0, 0, 0, 0, 0, 0])
    for enlace in range(-1, p.getNumJoints(fantasma)):
        p.changeVisualShape(fantasma, enlace, rgbaColor=COLOR_FANTASMA)
    return fantasma


def leer_deslizadores(visualizador):
    valores = visualizador.get_param_values()
    return [valores[f" j{i}"] for i in range(6)]


def copiar_a_deslizadores(visualizador, q):
    valores = visualizador.get_param_values()
    nuevos = {f"j{i}": valores[f" j{i}"] for i in range(len(valores))}
    nuevos.update({f"j{i}": angulo for i, angulo in enumerate(q)})
    visualizador.set_param_values(nuevos)


def atender_tecla(tecla, contexto):
    """Ejecuta la acción de una tecla. contexto agrupa el estado del programa."""
    robot, puntos = contexto["robot"], contexto["puntos"]
    secuenciador, visualizador = contexto["secuenciador"], contexto["visualizador"]
    ahora = time.monotonic()
    if tecla == "a":
        if robot["q"] is None:
            print("Todavía no se ha recibido la postura del robot.")
            return
        puntos.append(validar_punto(robot["q"]))
        print(f"Punto {len(puntos)} añadido desde el robot (grados): {en_grados(puntos[-1])}")
    elif tecla == "d":
        puntos.append(validar_punto(leer_deslizadores(visualizador)))
        print(f"Punto {len(puntos)} añadido desde los deslizadores (grados): {en_grados(puntos[-1])}")
    elif tecla == "t":
        if robot["q"] is None:
            print("Todavía no se ha recibido la postura del robot.")
            return
        copiar_a_deslizadores(visualizador, robot["q"])
        print("Deslizadores colocados en la postura actual del robot.")
    elif tecla == "b":
        if puntos:
            puntos.pop()
            print(f"Último punto borrado; quedan {len(puntos)}.")
        else:
            print("No hay puntos que borrar.")
    elif tecla == "v":
        if not puntos:
            print("No hay puntos que previsualizar.")
            return
        inicio = robot["q"] if robot["q"] is not None else puntos[0]
        contexto["previa"] = Previsualizacion(list(inicio), puntos, ahora)
        print(f"Previsualizando {len(puntos)} puntos en el robot translúcido.")
    elif tecla == "e":
        contexto["previa"] = None
        if secuenciador.fase != "parada" or not puntos or not robot["conectado"]:
            # iniciar() explica por qué no se puede ejecutar.
            secuenciador.iniciar(puntos, robot, ahora)
        elif contexto["ejecutar_tras_reconectar"] is not None:
            print("Ya se está rehaciendo la conexión.")
        elif rehacer_conexion(contexto["estado"]):
            # La secuencia empieza en el bucle principal con el primer estado nuevo.
            contexto["ejecutar_tras_reconectar"] = ahora + TIEMPO_RECONEXION
            print("Rehaciendo la conexión para que el robot acepte las órdenes en modo Remoto...")
    elif tecla == "r":
        secuenciador.reanudar(robot, ahora)
    elif tecla == "c":
        if contexto["previa"]:
            contexto["previa"] = None
            print("Previsualización cancelada.")
        if contexto["ejecutar_tras_reconectar"] is not None:
            contexto["ejecutar_tras_reconectar"] = None
            print("Ejecución cancelada antes de empezar.")
        secuenciador.cancelar(robot)
    elif tecla == "g":
        guardar_secuencia(puntos)
        print(f"Secuencia de {len(puntos)} puntos guardada en {FICHERO}.")
    elif tecla == "l":
        if secuenciador.fase != "parada":
            print("Cancela la secuencia en curso antes de cargar otra.")
            return
        puntos[:] = cargar_secuencia()
        print(f"Cargados {len(puntos)} puntos de {FICHERO}.")
    elif tecla == "h":
        print(AYUDA)


def main():
    try:
        ip = ip_destino(sys.argv)
    except ValueError as error:
        print(f"Error de configuración: {error}")
        return 1

    visualizador = UR3eRG2()
    # Sin los atajos de PyBullet (w, g, s...) todas las letras quedan libres.
    p.configureDebugVisualizer(p.COV_ENABLE_KEYBOARD_SHORTCUTS, 0)
    fantasma = crear_fantasma(visualizador)

    estado = tiempo_real.crear_estado()
    detener = threading.Event()
    config = {"nombre": "UR3e", "ip": ip, "puerto": primaria.PUERTO,
              "longitud_minima": primaria.LONGITUD_MINIMA, "decodificar": primaria.decodificar}
    hilo = threading.Thread(target=tiempo_real.recibir_robot, args=(config, estado, detener),
                            name="receptor", daemon=True)
    hilo.start()

    secuenciador = Secuenciador(lambda texto: enviar_urscript(estado, texto))
    contexto = {"robot": None, "puntos": [], "previa": None, "estado": estado,
                "ejecutar_tras_reconectar": None,   # plazo para empezar tras pulsar E
                "secuenciador": secuenciador, "visualizador": visualizador}
    texto_ventana, id_texto = None, -1
    print(AYUDA)
    print("Salir: Ctrl+C o cerrar la ventana de PyBullet.")
    try:
        while ventana_abierta():
            ahora = time.monotonic()
            with estado["lock"]:
                robot = {campo: estado[campo] for campo in CAMPOS_ROBOT}
                mensajes = list(estado["mensajes"])
                estado["mensajes"].clear()
            contexto["robot"] = robot
            if robot["q"] is not None:
                visualizador.move_robot(0, list(robot["q"]))

            # Se comprueba antes de leer el teclado: robot es la foto de esta
            # vuelta, tomada después de cerrar la conexión antigua.
            plazo = contexto["ejecutar_tras_reconectar"]
            if plazo is not None:
                if robot["conectado"] and robot["programa_en_marcha"] is not None:
                    contexto["ejecutar_tras_reconectar"] = None
                    secuenciador.iniciar(contexto["puntos"], robot, ahora)
                elif ahora > plazo:
                    contexto["ejecutar_tras_reconectar"] = None
                    print(f"No se ha recibido estado por la conexión nueva en {TIEMPO_RECONEXION} s; "
                          "la secuencia no se ha ejecutado.")

            for codigo, flags in p.getKeyboardEvents().items():
                if flags & p.KEY_WAS_TRIGGERED and codigo < 256:
                    try:
                        atender_tecla(chr(codigo).lower(), contexto)
                    except (OSError, ValueError) as error:
                        print(f"Error: {error}")
            secuenciador.actualizar(robot, mensajes, ahora)

            previa = contexto["previa"]
            pose = previa.pose(ahora) if previa else None
            if pose is None:
                if previa:
                    print("Previsualización terminada.")
                    contexto["previa"] = None
                pose = leer_deslizadores(visualizador)
            visualizador.move_robot(fantasma, pose)

            texto = f"Puntos: {len(contexto['puntos'])}  |  Secuencia: {secuenciador.descripcion()}"
            if contexto["ejecutar_tras_reconectar"] is not None:
                texto += "  |  rehaciendo la conexión"
            elif not robot["conectado"]:
                texto += "  |  sin conexión"
            if texto != texto_ventana:
                id_texto = p.addUserDebugText(texto[:110], [0, -0.5, 0.8], textColorRGB=[0, 0, 0],
                                              textSize=1.2, replaceItemUniqueId=id_texto)
                texto_ventana = texto
            time.sleep(1 / 60)
    except KeyboardInterrupt:
        print("Interrumpido con Ctrl+C.")
    except p.error:
        # Cerrar la ventana a mitad de una llamada a PyBullet lanza p.error.
        if ventana_abierta():
            raise
    finally:
        # Al salir no se deja el robot moviéndose hacia un punto.
        if secuenciador.activa and contexto["robot"] is not None:
            secuenciador.cancelar(contexto["robot"])
        detener.set()
        hilo.join(timeout=2)
        if ventana_abierta():
            p.disconnect()
    print("Programa terminado.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
