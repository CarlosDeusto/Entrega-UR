"""Bloque C: varios robots en la misma ventana de PyBullet.

Uso: python multirobot.py
Los robots (nombre, ip, puerto y posición en la escena) se leen de
robots.json, sin tocar el código. Cada robot tiene su propio hilo receptor,
socket y buffer, así que si uno se desconecta los demás siguen moviéndose.
"""
import math

import pybullet as p
from UR3e_rg2.dynamic_ur3e import UR3eRG2

import primaria
import tiempo_real
from configuracion import cargar_robots


def main():
    try:
        robots = cargar_robots()
    except ValueError as error:
        print(f"Error de configuración: {error}")
        return 1

    # Un único UR3eRG2 por proceso. Su primer robot (id 0) se coloca en la
    # posición del primero del JSON; el resto se añade con spawn_robot().
    visualizador = UR3eRG2()
    for numero, robot in enumerate(robots):
        posicion = robot["posicion"]
        if numero == 0:
            robot["id"] = 0
            p.resetBasePositionAndOrientation(0, posicion[:3], p.getQuaternionFromEuler(posicion[3:]))
        else:
            robot["id"] = visualizador.spawn_robot(posicion)
        # El puerto decide la interfaz: tamaño mínimo de mensaje y decodificador.
        interfaz = primaria if robot["puerto"] == primaria.PUERTO else tiempo_real
        robot["longitud_minima"] = interfaz.LONGITUD_MINIMA
        robot["decodificar"] = interfaz.decodificar

    # Cámara centrada en el conjunto de robots.
    bases = [robot["posicion"][:3] for robot in robots]
    centro = [sum(base[eje] for base in bases) / len(bases) for eje in range(3)]
    radio = max(math.dist(base, centro) for base in bases)
    p.resetDebugVisualizerCamera(cameraDistance=max(2.5, 2 * radio + 1.5), cameraYaw=50,
                                 cameraPitch=-35, cameraTargetPosition=centro)

    tiempo_real.visualizar(visualizador, robots)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
