"""Bloque A: visualizador de un UR3e mediante la interfaz primaria (puerto 30001).

Uso: python primaria.py [IP]
Sin IP se usa la del primer robot de robots.json.

Un único bucle recibe, decodifica y actualiza PyBullet. El socket tiene un
timeout corto para que el bucle no se quede bloqueado esperando a la red.

Ninguna llamada a recv() pide un tamaño fijo elegido a ojo: primero se piden
los 4 bytes del campo longitud y después exactamente los bytes que faltan del
mensaje. Así una lectura nunca trae el principio del mensaje siguiente y el
flujo no se desalinea.
"""
import math
import socket
import struct
import sys
import time

import pybullet as p
from UR3e_rg2.dynamic_ur3e import UR3eRG2

from configuracion import ip_destino

PUERTO = 30001
TAM_LONGITUD = 4              # todo mensaje, en 30001 y en 30003, empieza por su longitud (int)
CABECERA = 5                  # longitud (int, 4 B) + tipo (unsigned char, 1 B)
LONGITUD_MINIMA = CABECERA    # la longitud incluye la cabecera
# Solo sirve para detectar desalineación, no se pasa a recv(). El enunciado
# propone 64 kB; los mensajes medidos no pasan de 1.473 B.
LONGITUD_MAXIMA = 65536
TAM_ARTICULACION = struct.calcsize(">dddffffB")    # 41 bytes por articulación
TAM_JOINT_DATA = CABECERA + 6 * TAM_ARTICULACION   # 251 bytes
TIEMPO_SIN_DATOS = 3          # segundos sin estados antes de reconectar
INTERVALO_REINTENTO = 1       # segundos entre intentos de conexión

# robotMode, igual en la interfaz primaria y en la de tiempo real.
MODOS = {
    -1: "sin controlador", 0: "desconectado", 1: "confirmando seguridad",
    2: "arrancando", 3: "apagado", 4: "encendiendo", 5: "en reposo (frenos puestos)",
    6: "guiado manual", 7: "listo (frenos liberados)", 8: "actualizando firmware",
    9: "apagándose",
}
NIVELES = {0: "depuración", 1: "información", 2: "advertencia", 3: "violación", 4: "fallo"}
MODOS_SEGURIDAD = {
    1: "normal", 2: "reducido", 3: "parada de protección", 4: "recuperación",
    5: "parada de salvaguarda", 6: "parada de emergencia del sistema",
    7: "parada de emergencia del robot", 8: "violación", 9: "fallo",
    10: "validando articulaciones", 11: "indefinido",
    12: "parada de salvaguarda automática", 13: "parada por dispositivo de habilitación",
}


def recibir_exacto(conexion, buffer, n):
    """Completa buffer hasta n bytes pidiendo a recv() solo los que faltan.

    recv(n - len(buffer)) puede devolver menos de lo pedido, nunca más, así que
    se repite hasta completar. Devuelve False si salta el timeout del socket;
    lo ya recibido se queda en buffer y se continúa en la siguiente llamada.
    """
    while len(buffer) < n:
        try:
            datos = conexion.recv(n - len(buffer))
        except socket.timeout:
            return False
        if not datos:
            raise ConnectionError("el robot o URSim ha cerrado la conexión")
        buffer.extend(datos)
    return True


def recibir_mensaje(conexion, buffer, longitud_minima):
    """Devuelve el siguiente mensaje completo, o None si aún no ha llegado entero.

    1. recv() de los 4 bytes de la longitud L.
    2. recv() de los L - 4 bytes restantes (L incluye la propia cabecera).
    buffer guarda el mensaje a medias entre llamadas y se vacía al terminarlo.
    """
    if not recibir_exacto(conexion, buffer, TAM_LONGITUD):
        return None
    longitud = struct.unpack_from(">i", buffer)[0]
    if not longitud_minima <= longitud <= LONGITUD_MAXIMA:
        raise ValueError(f"longitud de mensaje imposible ({longitud})")
    if not recibir_exacto(conexion, buffer, longitud):
        return None
    mensaje = bytes(buffer)
    buffer.clear()
    return mensaje


def leer_version(mensaje):
    """Versión del software en el mensaje 20 con robotMessageType 3, o None."""
    # timestamp (uint64), source (char), robotMessageType (char), projectNameSize (char)
    if len(mensaje) < CABECERA + 11:
        return None
    _, _, subtipo, tam_nombre = struct.unpack_from(">QbBB", mensaje, CABECERA)
    if subtipo != 3:
        return None
    # Tras el nombre del proyecto: majorVersion, minorVersion, bugfixVersion, buildNumber
    posicion = CABECERA + 11 + tam_nombre
    if len(mensaje) < posicion + 10:
        return None
    mayor, menor, revision, compilacion = struct.unpack_from(">BBii", mensaje, posicion)
    return f"{mayor}.{menor}.{revision}.{compilacion}"


def _texto(datos):
    return datos.decode("utf-8", errors="replace").strip()


def leer_mensaje_robot(mensaje):
    """Mensaje 20: versión (subtipo 3) o aviso para el operador, o None.

    Los avisos se marcan como graves si deben detener una secuencia:
    excepciones del programa, errores de nivel advertencia o superior y
    modos de seguridad distintos de normal o reducido.
    """
    # Tras la cabecera: timestamp (8 B), source (1 B) y robotMessageType (1 B).
    if len(mensaje) < CABECERA + 10:
        return None
    subtipo = mensaje[CABECERA + 9]
    if subtipo == 3:
        version = leer_version(mensaje)
        return {"version": version} if version else None
    datos = mensaje[CABECERA + 10:]
    if subtipo == 0:
        texto, grave = _texto(datos), False
    elif subtipo == 5 and len(datos) >= 17:
        # robotMessageCode, robotMessageArgument, safetyModeType, reportDataType, reportData
        codigo, argumento, modo = struct.unpack_from(">iiB", datos)
        texto = f"C{codigo}A{argumento}: modo de seguridad {MODOS_SEGURIDAD.get(modo, modo)}"
        grave = modo not in (1, 2)
    elif subtipo == 6 and len(datos) >= 20:
        # robotMessageCode, robotMessageArgument, robotMessageReportLevel,
        # robotMessageDataType, robotMessageData (cinco enteros) y el texto
        codigo, argumento, nivel = struct.unpack_from(">iii", datos)
        texto = f"C{codigo}A{argumento} ({NIVELES.get(nivel, f'nivel {nivel}')}) {_texto(datos[20:])}"
        grave = 2 <= nivel <= 4
    elif subtipo == 7 and len(datos) >= 9:
        # robotMessageCode, robotMessageArgument, tamaño del título, título y texto
        codigo, argumento, tam_titulo = struct.unpack_from(">iiB", datos)
        titulo, cuerpo = _texto(datos[9:9 + tam_titulo]), _texto(datos[9 + tam_titulo:])
        texto, grave = f"C{codigo}A{argumento}: {titulo} {cuerpo}".strip(), False
    elif subtipo == 10 and len(datos) >= 8:
        # scriptLineNumber, scriptColumnNumber y el texto de la excepción
        linea, columna = struct.unpack_from(">ii", datos)
        texto, grave = f"excepción en línea {linea}, columna {columna}: {_texto(datos[8:])}", True
    else:
        return None
    return {"mensaje": {"tipo": subtipo, "texto": texto, "grave": grave}}


def leer_estado(mensaje):
    """Recorre los subpaquetes de un mensaje de estado (tipo 16)."""
    estado = {}
    posicion = CABECERA
    while posicion < len(mensaje):
        if posicion + CABECERA > len(mensaje):
            raise ValueError("cabecera de subpaquete incompleta")
        tam, tipo = struct.unpack_from(">iB", mensaje, posicion)
        if tam < CABECERA or posicion + tam > len(mensaje):
            raise ValueError(f"el subpaquete de tipo {tipo} se sale del mensaje")
        if tipo == 0 and tam >= CABECERA + 16:
            # Robot mode data: timestamp, isRealRobotConnected, isRealRobotEnabled,
            # isRobotPowerOn, isEmergencyStopped, isProtectiveStopped,
            # isProgramRunning, isProgramPaused y robotMode.
            campos = struct.unpack_from(">Q???????B", mensaje, posicion + CABECERA)
            estado.update(parada_emergencia=campos[4], parada_proteccion=campos[5],
                          programa_en_marcha=campos[6], modo=campos[8])
        elif tipo == 1:
            if tam != TAM_JOINT_DATA:
                raise ValueError(f"Joint data mide {tam} bytes y se esperaban {TAM_JOINT_DATA}")
            q = [
                struct.unpack_from(">d", mensaje, posicion + CABECERA + j * TAM_ARTICULACION)[0]
                for j in range(6)
            ]
            if not all(math.isfinite(angulo) for angulo in q):
                raise ValueError("ángulos articulares no válidos")
            estado["q"] = q
        posicion += tam
    return estado


def decodificar(mensaje):
    """Datos útiles de un mensaje completo, o None si no interesa.

    Los mensajes de otros tipos se ignoran: ya se han leído enteros gracias a
    su longitud, así que el siguiente empieza en su sitio.
    """
    tipo = mensaje[TAM_LONGITUD]
    if tipo == 16:
        return leer_estado(mensaje)
    if tipo == 20:
        return leer_mensaje_robot(mensaje)
    return None


def ventana_abierta():
    """La ventana puede cerrarse mientras consultamos su estado."""
    try:
        return bool(p.isConnected())
    except p.error:
        return False


def en_grados(q):
    return [round(math.degrees(angulo), 2) for angulo in q]


def main():
    try:
        ip = ip_destino(sys.argv)
    except ValueError as error:
        print(f"Error de configuración: {error}")
        return 1

    visualizador = UR3eRG2()
    print("Salir: Ctrl+C o cerrar la ventana de PyBullet.")
    conexion = None
    aviso_espera = False
    try:
        while ventana_abierta():
            if conexion is None:
                try:
                    conexion = socket.create_connection((ip, PUERTO), timeout=1)
                except OSError as error:
                    if not aviso_espera:
                        print(f"Esperando a {ip}:{PUERTO} ({error}); "
                              f"reintento cada {INTERVALO_REINTENTO} s...")
                        aviso_espera = True
                    time.sleep(INTERVALO_REINTENTO)
                    continue
                # 0,1 s es el periodo de los estados de la primaria (10 Hz):
                # si en ese tiempo no llega nada, se vuelve a comprobar la ventana.
                conexion.settimeout(0.1)
                print(f"Conectado a {ip}:{PUERTO}.")
                aviso_espera = False
                buffer = bytearray()
                modo = q = None
                estados = 0
                ultimo_estado = ultimo_informe = time.monotonic()

            try:
                mensaje = recibir_mensaje(conexion, buffer, LONGITUD_MINIMA)
                estado = decodificar(mensaje) if mensaje else None
                if estado:
                    if "version" in estado:
                        print(f"Versión del software del robot: {estado['version']}")
                    if "mensaje" in estado:
                        print(f"Mensaje del robot: {estado['mensaje']['texto']}")
                    if "modo" in estado and estado["modo"] != modo:
                        modo = estado["modo"]
                        print(f"Estado del robot: {MODOS.get(modo, f'modo {modo}')}.")
                    if "q" in estado:
                        q = estado["q"]
                        visualizador.move_robot(0, list(q))
                        estados += 1
                        ultimo_estado = time.monotonic()
                if time.monotonic() - ultimo_estado > TIEMPO_SIN_DATOS:
                    raise ConnectionError(f"más de {TIEMPO_SIN_DATOS} s sin mensajes de estado")
            except (OSError, ValueError) as error:
                print(f"Desconectado: {error}. Se conserva la última postura "
                      "y se espera la reconexión.")
                conexion.close()
                conexion = None
                continue

            ahora = time.monotonic()
            if ahora - ultimo_informe >= 1:
                if estados:
                    print(f"{estados / (ahora - ultimo_informe):.0f} estados/s; "
                          f"q (grados): {en_grados(q)}")
                estados = 0
                ultimo_informe = ahora
    except KeyboardInterrupt:
        print("Interrumpido con Ctrl+C.")
    except p.error:
        # Cerrar la ventana a mitad de move_robot() lanza p.error.
        if ventana_abierta():
            raise
    finally:
        if conexion is not None:
            conexion.close()
        if ventana_abierta():
            p.disconnect()
    print("Programa terminado.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
