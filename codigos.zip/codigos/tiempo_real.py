"""Bloque B: visualizador de un UR3e mediante la interfaz de tiempo real (puerto 30003).

Uso: python tiempo_real.py [IP]
Sin IP se usa la del primer robot de robots.json.

A unos 500 paquetes/s no se puede dibujar cada paquete: un hilo receptor
consume todo lo que llega y guarda solo el último estado, y el bucle principal
dibuja a 60 Hz. multirobot.py reutiliza esta misma estructura con un hilo por
robot.

El receptor lee paquete a paquete con primaria.recibir_mensaje(): recv() de
los 4 bytes de la longitud y recv() de los que faltan. Como cada paquete se
procesa en cuanto está completo y no se lee nada del siguiente, el hilo va al
ritmo del robot y la postura guardada es siempre la última que ha llegado.
"""
import collections
import math
import socket
import struct
import sys
import threading
import time

import pybullet as p
from UR3e_rg2.dynamic_ur3e import UR3eRG2

from configuracion import ip_destino
from primaria import MODOS, en_grados, recibir_mensaje, ventana_abierta

PUERTO = 30003
# La cabecera es solo la longitud (int, 4 B): no hay campo de tipo. La
# longitud total depende de la versión, así que se lee del propio paquete.
LONGITUD_MINIMA = 300         # q actual ocupa los bytes 252 a 299
DESPLAZAMIENTO_Q = 252
DESPLAZAMIENTO_MODO = 756
TIEMPO_SIN_DATOS = 3          # segundos sin estados antes de reconectar
INTERVALO_REINTENTO = 1       # segundos entre intentos de conexión
PERIODO_DIBUJO = 1 / 60


def decodificar(paquete):
    """Lee q actual y, si la versión lo incluye, el modo del robot."""
    q = list(struct.unpack_from(">6d", paquete, DESPLAZAMIENTO_Q))
    if not all(math.isfinite(angulo) for angulo in q):
        raise ValueError("ángulos articulares no válidos")
    estado = {"q": q}
    if len(paquete) >= DESPLAZAMIENTO_MODO + 8:
        # Aquí el modo viaja como double aunque sea un entero.
        modo = struct.unpack_from(">d", paquete, DESPLAZAMIENTO_MODO)[0]
        if math.isfinite(modo) and modo.is_integer():
            estado["modo"] = int(modo)
    return estado


def avisar(texto):
    """print() escribe el texto y el salto de línea por separado; con varios
    hilos a la vez se mezclarían líneas, así que se escriben juntos."""
    print(texto + "\n", end="", flush=True)


# Indicadores del subpaquete 0 de la primaria; en tiempo real no llegan.
INDICADORES = ("programa_en_marcha", "parada_proteccion", "parada_emergencia")


def crear_estado():
    """Estado compartido entre un hilo receptor y el bucle de dibujo.

    conexion permite al hilo principal escribir órdenes en el mismo socket
    del que lee el receptor; mensajes guarda los últimos avisos del robot.
    reconectar indica que el hilo principal ha cerrado la conexión a propósito
    para que el receptor abra otra enseguida.
    """
    estado = {"q": None, "modo": None, "paquetes": 0, "conectado": False, "conexion": None,
              "reconectar": False, "mensajes": collections.deque(maxlen=20),
              "lock": threading.Lock()}
    estado.update(dict.fromkeys(INDICADORES))
    return estado


def recibir(conexion, robot, estado, detener):
    """Consume la conexión mensaje a mensaje y guarda el último estado.

    robot["longitud_minima"] y robot["decodificar"] dependen de la interfaz.
    """
    nombre, decodificar = robot["nombre"], robot["decodificar"]
    buffer = bytearray()
    ultimo_estado = time.monotonic()
    while not detener.is_set():
        mensaje = recibir_mensaje(conexion, buffer, robot["longitud_minima"])
        nuevo = decodificar(mensaje) if mensaje else None
        if nuevo:
            if "version" in nuevo:
                avisar(f"[{nombre}] Versión del software del robot: {nuevo['version']}")
            if "mensaje" in nuevo:
                avisar(f"[{nombre}] Mensaje del robot: {nuevo['mensaje']['texto']}")
            cambio_modo = False
            with estado["lock"]:
                if "q" in nuevo:
                    estado["q"] = nuevo["q"]
                    estado["paquetes"] += 1
                    ultimo_estado = time.monotonic()
                for campo in INDICADORES:
                    if campo in nuevo:
                        estado[campo] = nuevo[campo]
                if "mensaje" in nuevo:
                    estado["mensajes"].append(nuevo["mensaje"])
                if "modo" in nuevo and nuevo["modo"] != estado["modo"]:
                    estado["modo"] = nuevo["modo"]
                    cambio_modo = True
            if cambio_modo:
                modo = nuevo["modo"]
                avisar(f"[{nombre}] Estado del robot: {MODOS.get(modo, f'modo {modo}')}.")
        if time.monotonic() - ultimo_estado > TIEMPO_SIN_DATOS:
            raise ConnectionError(f"más de {TIEMPO_SIN_DATOS} s sin estados completos")


def recibir_robot(robot, estado, detener):
    """Hilo receptor de un robot: conecta, recibe y reconecta si se cae."""
    nombre, ip, puerto = robot["nombre"], robot["ip"], robot["puerto"]
    aviso_espera = False
    while not detener.is_set():
        try:
            conexion = socket.create_connection((ip, puerto), timeout=1)
        except OSError as error:
            if not aviso_espera:
                avisar(f"[{nombre}] Esperando a {ip}:{puerto} ({error}); "
                      f"reintento cada {INTERVALO_REINTENTO} s...")
                aviso_espera = True
            detener.wait(INTERVALO_REINTENTO)
            continue
        aviso_espera = False
        avisar(f"[{nombre}] Conectado a {ip}:{puerto}.")
        # Si no llega nada en 0,2 s, recv() vuelve para comprobar detener.
        conexion.settimeout(0.2)
        with estado["lock"]:
            estado.update(dict.fromkeys(INDICADORES), conectado=True, conexion=conexion,
                          modo=None, paquetes=0)
        error = None
        try:
            with conexion:
                recibir(conexion, robot, estado, detener)
        except (OSError, ValueError) as fallo:
            error = fallo
        finally:
            with estado["lock"]:
                pedida = estado["reconectar"]
                estado.update(dict.fromkeys(INDICADORES), conectado=False, conexion=None,
                              reconectar=False)
        if pedida:
            # Cierre pedido por el hilo principal: se abre otra conexión sin esperar.
            avisar(f"[{nombre}] Conexión cerrada para abrir una nueva.")
            continue
        if error and not detener.is_set():
            avisar(f"[{nombre}] Desconectado: {error}. Se conserva la última postura "
                   "y se espera la reconexión.")
        detener.wait(INTERVALO_REINTENTO)


def visualizar(visualizador, robots):
    """Lanza un hilo receptor por robot y dibuja hasta cerrar la ventana.

    Cada robot es un diccionario con nombre, ip, puerto, id (de PyBullet) y la
    longitud_minima y la función decodificar de su interfaz. PyBullet solo se
    llama desde aquí.
    """
    detener = threading.Event()
    estados = [crear_estado() for _ in robots]
    hilos = []
    for robot, estado in zip(robots, estados):
        hilo = threading.Thread(target=recibir_robot, args=(robot, estado, detener),
                                name=f"receptor-{robot['nombre']}", daemon=True)
        hilo.start()
        hilos.append(hilo)

    print("Salir: Ctrl+C o cerrar la ventana de PyBullet.")
    ultimo_informe = time.monotonic()
    try:
        while ventana_abierta():
            for robot, estado in zip(robots, estados):
                with estado["lock"]:
                    q = estado["q"]
                if q is not None:
                    visualizador.move_robot(robot["id"], list(q))

            ahora = time.monotonic()
            if ahora - ultimo_informe >= 1:
                for robot, estado in zip(robots, estados):
                    with estado["lock"]:
                        q, paquetes = estado["q"], estado["paquetes"]
                        estado["paquetes"] = 0
                    if paquetes:
                        avisar(f"[{robot['nombre']}] {paquetes / (ahora - ultimo_informe):.0f} "
                               f"paquetes/s; q (grados): {en_grados(q)}")
                ultimo_informe = ahora
            time.sleep(PERIODO_DIBUJO)
    except KeyboardInterrupt:
        print("Interrumpido con Ctrl+C.")
    except p.error:
        # Cerrar la ventana a mitad de move_robot() lanza p.error.
        if ventana_abierta():
            raise
    finally:
        detener.set()
        limite = time.monotonic() + 2
        for hilo in hilos:
            hilo.join(timeout=max(0, limite - time.monotonic()))
        if ventana_abierta():
            p.disconnect()
    print("Programa terminado.")


def main():
    try:
        ip = ip_destino(sys.argv)
    except ValueError as error:
        print(f"Error de configuración: {error}")
        return 1
    visualizador = UR3eRG2()
    visualizar(visualizador, [
        {"nombre": "UR3e", "ip": ip, "puerto": PUERTO, "id": 0,
         "longitud_minima": LONGITUD_MINIMA, "decodificar": decodificar},
    ])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
