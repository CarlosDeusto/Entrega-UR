"""Lee las conexiones y las posiciones de los robots desde robots.json."""
import json
import math
from pathlib import Path


def cargar_robots():
    """Devuelve la lista de robots, o un error claro si falta algún dato."""
    # Buscamos el JSON junto a este archivo, aunque ejecutemos Python desde
    # otra carpeta. Para cambiar los robots solo hay que editar ese JSON.
    ruta = Path(__file__).with_name("robots.json")
    try:
        with ruta.open(encoding="utf-8-sig") as archivo:
            robots = json.load(archivo)
    except OSError as error:
        raise ValueError(f"No se puede leer {ruta}: {error}") from error
    except ValueError as error:
        raise ValueError(f"El archivo {ruta} no contiene un JSON válido: {error}") from error

    if not isinstance(robots, list) or not robots:
        raise ValueError("robots.json debe contener una lista con al menos un robot")

    nombres = []
    for numero, robot in enumerate(robots, start=1):
        # Revisamos los datos antes de abrir PyBullet o intentar conectar.
        # Así un error de configuración no deja una ventana abierta sin robots.
        etiqueta = f"Robot {numero} de robots.json"
        if not isinstance(robot, dict):
            raise ValueError(f"{etiqueta}: debe ser un objeto con nombre, ip, puerto y posicion")
        for campo in ("nombre", "ip", "puerto", "posicion"):
            if campo not in robot:
                raise ValueError(f"{etiqueta}: falta el campo '{campo}'")

        nombre = robot["nombre"]
        if not isinstance(nombre, str) or not nombre.strip():
            raise ValueError(f"{etiqueta}: 'nombre' debe ser un texto no vacío")
        nombre = nombre.strip()
        if nombre in nombres:
            raise ValueError(f"{etiqueta}: el nombre '{nombre}' está repetido")
        nombres.append(nombre)
        robot["nombre"] = nombre

        ip = robot["ip"]
        if not isinstance(ip, str) or not ip.strip():
            raise ValueError(f"{etiqueta}: 'ip' debe contener la dirección del robot o de URSim")
        robot["ip"] = ip.strip()

        # Estos son los dos protocolos que saben interpretar nuestros programas.
        # bool se excluye porque Python también lo considera un tipo de entero.
        puerto = robot["puerto"]
        if isinstance(puerto, bool) or not isinstance(puerto, int) or puerto not in (30001, 30003):
            raise ValueError(f"{etiqueta}: 'puerto' debe ser 30001 (primaria) o 30003 (tiempo real)")

        # La posición de la BASE del modelo se indica con seis números:
        # [x, y, z, giro_x, giro_y, giro_z], en metros y radianes.
        # Estos valores colocan el robot en la ventana; no mandan movimientos.
        posicion = robot["posicion"]
        if not isinstance(posicion, list) or len(posicion) != 6:
            raise ValueError(f"{etiqueta}: 'posicion' debe ser una lista de seis números")
        for valor in posicion:
            if isinstance(valor, bool) or not isinstance(valor, (int, float)):
                raise ValueError(f"{etiqueta}: los seis valores de 'posicion' deben ser números")
            try:
                finito = math.isfinite(valor)
            except OverflowError:
                finito = False
            if not finito:
                raise ValueError(f"{etiqueta}: los seis valores de 'posicion' deben ser finitos")
    return robots


def ip_destino(argumentos):
    """IP pasada como argumento o, si no hay, la del primer robot del JSON."""
    if len(argumentos) > 1:
        return argumentos[1]
    return cargar_robots()[0]["ip"]
